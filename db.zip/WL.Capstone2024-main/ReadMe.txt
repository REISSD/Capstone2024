Hey its me, Wang

The "db" folder has the database for mysql workbench,

If not, you can importing the tables THEN the data in the "datafolder"
	1 - Use the "createCapstoneTable.sql" to make the tables
	2 - Import the data from the "datafolder", they are formatted as .sql

LMK if there are any issue on discord Thanks